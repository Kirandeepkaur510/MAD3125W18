package in.graphisigner.www.paypark;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SupportContact extends AppCompatActivity implements View.OnClickListener {

    Button btnCall, btnSMS, btnEmail;
    EditText Subject, Message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support_contact);

        btnCall = (Button) findViewById(R.id.btnCall);
        btnCall.setOnClickListener(this);

        btnSMS = (Button) findViewById(R.id.btnSMS);
        btnSMS.setOnClickListener(this);

        btnEmail = (Button) findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);

        Subject = (EditText) findViewById(R.id.subject);
        Message = (EditText) findViewById(R.id.message);

        Subject.setOnClickListener(this);
        Message.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btnCall:
                makeCall();
                break;
            case R.id.btnEmail:
                String subj = Subject.getText().toString();
                String messg = Message.getText().toString();
                if(subj.isEmpty()||messg.isEmpty())
                {
                    Toast.makeText(this, "Data Missing!" , Toast.LENGTH_LONG).show();
                }
                else {
                    sendEmail(subj, messg);
                }
                break;
            case R.id.btnSMS:
                sendSMS();
                break;
        }
    }

    private void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:3657735759"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }

    private void sendEmail(String subj, String message){

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"nk.dushila@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subj);
        emailIntent.putExtra(Intent.EXTRA_TEXT,message);

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }

    private void sendSMS(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:3657735759"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
}
