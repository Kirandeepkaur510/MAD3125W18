package in.graphisigner.www.paypark;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

public class LogIn extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    Button btnRegister;
    EditText txtboxUsername;
    EditText txtboxPassword;

    DBHelper dbHelper;
    SQLiteDatabase PayParkDB_Img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        txtboxPassword = findViewById(R.id.txtboxPassword);
        txtboxUsername = findViewById(R.id.txtboxUsername);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()) {
            String user = txtboxUsername.getText().toString();
            String pass = txtboxPassword.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Login Credential Missing!" + user, Toast.LENGTH_SHORT).show();
            }
            else if (verifyLogin()) {
                finish();
                Intent homeIntent = new Intent(this, Home.class);
                startActivity(homeIntent);
            } else {
                Toast.makeText(this, "Username and Password is not correct!", Toast.LENGTH_SHORT).show();
            }
        } else if (view.getId() == btnRegister.getId()) {
            Intent registerIntent = new Intent(this, Registration.class);
            startActivity(registerIntent);
        }

    }

    private boolean verifyLogin() {

        GlobalVariable.LoggedUser = txtboxUsername.getText().toString();
        for(int i=0; i<GlobalVariable.UserName.length; i++)
            {
                    if(GlobalVariable.LoggedUser.equals(GlobalVariable.UserName[i])){
                        GlobalVariable.UserIndex = i;
                        return true;
                    }
                    else
                    {
                        continue;
                    }
            }
            return false;

    }


    private boolean verifyLoginData() {

        try {
            PayParkDB_Img = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Phone", "Email", "City", "Password", "DOB", "UserImage"};
            Cursor cursor = PayParkDB_Img.query("UserInfo", columns, null, null, null, null, null);

            while (cursor.moveToNext()) {
                GlobalVariable.LoggedUser = txtboxUsername.getText().toString();

                String email = cursor.getString(cursor.getColumnIndex("Email"));

                if (email.equals(GlobalVariable.LoggedUser)) {
                    String name = cursor.getString(cursor.getColumnIndex("Name"));
                    String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                    String city = cursor.getString(cursor.getColumnIndex("City"));
                    String password = cursor.getString(cursor.getColumnIndex("Password"));
                    String birthdate = cursor.getString(cursor.getColumnIndex("DOB"));
                    String image = cursor.getString(cursor.getColumnIndex("UserImage"));
                    String userInfo = name + "\n" + phone + "\n" + email + "\n" + city + "\n" + password + "\n" + birthdate;
                    Toast.makeText(this, userInfo, Toast.LENGTH_SHORT).show();
                    break;

                } else {
                    continue;
                }

            }
        } catch (Exception e) {
            Log.e("RegistryActivity:", "Unable To Fetch Records");
        } finally {
            PayParkDB_Img.close();
        }


        return true;
}


}



