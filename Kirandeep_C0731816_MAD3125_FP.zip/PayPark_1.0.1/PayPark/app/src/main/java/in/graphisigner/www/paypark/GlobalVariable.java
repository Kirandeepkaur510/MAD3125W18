package in.graphisigner.www.paypark;

import java.util.ArrayList;
import java.util.Arrays;

public class GlobalVariable {

    public static String LoggedUser = "";
    public static int UserIndex = 0;

    public static String UserName[] = {"nk", "harinder", "kiran", "test"};
    public static String UserFullName[] = {"Naveen Dushila", "Harinder Kaur", "Kirandeep kaur", "test"};
    public static String Passwords[] = {"nk", "harinder", "kiran", "test"};
    public static String UserPhone[] = {"123456789", "1234568527", "258369147", "963258741"};
    public static String UserCity[] = {"Toronto", "Brampton", "Mississuaga", "Test"};
    public static String UserDOB[] = {"12-05-1999", "01-01-2015", "02-02-2018", "01-01-2018"};
    public static int UserImage[] = {R.drawable.nk, R.drawable.harinder, R.drawable.kiran, R.drawable.test};

    public static String RunTimeUser = "";
    public static Boolean RunTimer = false;
    public static int RunTImerHrs = 0;
    public static int RunTimerMins = 0;
    public static int RunTimerSecs = 0;

    public static int carLogo[] = {R.drawable.astonmartin, R.drawable.audi, R.drawable.bentley, R.drawable.bmw, R.drawable.chevrolet, R.drawable.ferrari, R.drawable.fiat, R.drawable.ford, R.drawable.honda, R.drawable.hyundai, R.drawable.infiniti, R.drawable.jaguar, R.drawable.jeep, R.drawable.kia, R.drawable.lamborghini, R.drawable.landrover, R.drawable.lexus, R.drawable.mazda, R.drawable.mercedes, R.drawable.mini, R.drawable.mitsubishi, R.drawable.nissan, R.drawable.porsche, R.drawable.renault, R.drawable.rollsroyce, R.drawable.skoda, R.drawable.subaru, R.drawable.suzuki, R.drawable.toyota, R.drawable.volkswagen, R.drawable.volvo};
    public static String carBrand[] = {"Aston Martin", "Audi", "Bentley", "BMW", "Chevrolet", "Ferrari", "Fiat", "Ford", "Honda", "Hyundai", "Infiniti", "Jaguar", "Jeep", "KIA", "Lamborghini", "Land Rover", "Lexus", "Mazda", "Mercedes", "Mini", "Mitsubishi", "Nissan", "Porsche", "Renault", "Rolls Royce", "Skoda", "Subaru", "Suzuki", "Toyota", "Volkswagen", "Volvo"};

    public static ArrayList<String> carAdded = new ArrayList<>(Arrays.asList("ABC123", "EFG859", "RTS125", "TYR125"));

    public static ArrayList<String> parkPayments = new ArrayList<>(Arrays.asList("ABC123", "EFG859", "RTS125", "TYR125"));
    public static ArrayList<String> PaymentDate = new ArrayList<>(Arrays.asList("01-01-2018", "02-03-2018", "03-04-2018", "05-05-2018"));
    public static ArrayList<String> PayHrs = new ArrayList<>(Arrays.asList("1", "2", "2", "3"));
    public static ArrayList<String> PayAmt = new ArrayList<>(Arrays.asList("5.65", "11.30", "11.30", "16.95"));

}

