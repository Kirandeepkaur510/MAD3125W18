package in.graphisigner.www.paypark;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Calendar;

public class UserProfile extends AppCompatActivity implements View.OnClickListener {

    private static final int RESULT_LOAD_IMAGE = 1;
    DBHelper dbHelper;
    SQLiteDatabase PayParkDB_Img;
    ImageView userImage;
    Button updateInfo;
    EditText fullName, email, phone, city, pass, cpass;
    TextView dob;

    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        userImage = (ImageView) findViewById(R.id.imgUserImageUpdate);
        userImage.setOnClickListener(this);

        updateInfo = (Button) findViewById(R.id.btnUpdateProfileUpdate);
        updateInfo.setOnClickListener(this);

        fullName = (EditText) findViewById(R.id.txtNameUpdate);
        email = (EditText) findViewById(R.id.txtEmailUpdate);
        phone = (EditText) findViewById(R.id.txtPhoneUpdate);
        city = (EditText) findViewById(R.id.txtCityUpdate);
        dob = (TextView) findViewById(R.id.txtDOBUpdate);
        pass = (EditText) findViewById(R.id.txtPasswordUpdate);
        cpass = (EditText) findViewById(R.id.txtConfirmPasswordUpdate);

        userImage.setImageResource(GlobalVariable.UserImage[GlobalVariable.UserIndex]);
        fullName.setText(GlobalVariable.UserFullName[GlobalVariable.UserIndex]);
        email.setText(GlobalVariable.LoggedUser);
        phone.setText(GlobalVariable.UserPhone[GlobalVariable.UserIndex]);
        city.setText(GlobalVariable.UserCity[GlobalVariable.UserIndex]);
        pass.setText(GlobalVariable.Passwords[GlobalVariable.UserIndex]);
        cpass.setText(GlobalVariable.Passwords[GlobalVariable.UserIndex]);
        dob.setText(GlobalVariable.UserDOB[GlobalVariable.UserIndex]);

        dob.setOnClickListener(this);
        userImage.setOnClickListener(this);
        updateInfo.setOnClickListener(this);
        email.setEnabled(false);

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == userImage.getId()) {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);
        } else if(view.getId() == updateInfo.getId())
        {
            updateUserInfo();
        }
        else if (view.getId() == dob.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

        }

    }

    public void updateUserInfo(){
        String userName = fullName.getText().toString();
        String userMail = email.getText().toString();
        String userPhone = phone.getText().toString();
        String userCity = city.getText().toString();
        String userDOB = dob.getText().toString();
        String userPass = pass.getText().toString();
        String userCPass = cpass.getText().toString();

        if(userName.isEmpty() || userMail.isEmpty() || userPhone.isEmpty()
                || userCity.isEmpty()||userDOB.isEmpty()||userPass.isEmpty()||userCPass.isEmpty())
        {
            Toast.makeText(this, "Data Missing!" , Toast.LENGTH_LONG).show();
        }
        else if (!userPass.equals(userCPass))
        {
            Toast.makeText(this, "Password Doesn't Match!" , Toast.LENGTH_LONG).show();
        }
        else
        {
            GlobalVariable.UserFullName[GlobalVariable.UserIndex] = userName;
            GlobalVariable.UserCity[GlobalVariable.UserIndex] = userCity;
            GlobalVariable.UserPhone[GlobalVariable.UserIndex] = userPhone;
            GlobalVariable.UserDOB[GlobalVariable.UserIndex] = userDOB;
            GlobalVariable.Passwords[GlobalVariable.UserIndex] = userPass;
            Toast.makeText(this, "Data Updated!" , Toast.LENGTH_LONG).show();
            Intent homeIntent = new Intent(this, Home.class);
            startActivity(homeIntent);
        }

    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month);
            String dd = String.valueOf(dayOfMonth);
            if(month<10)
            {
                mm = "0" + mm ;
            }
            if (dayOfMonth<10)
            {
                dd = "0" + dd;
            }
            dob.setText(mm + "-" + dd + "-" + yy);
        }
    };



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if( requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null)
        {
            Uri selectedImage = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImage);
                userImage.setImageBitmap(bitmap);
            }
            catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

}
