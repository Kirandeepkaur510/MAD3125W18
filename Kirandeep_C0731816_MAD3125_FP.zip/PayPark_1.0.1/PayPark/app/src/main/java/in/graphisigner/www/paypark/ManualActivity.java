package in.graphisigner.www.paypark;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;


public class ManualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);

        WebView webManual = (WebView) findViewById(R.id.WebManual);

        webManual.getSettings().setJavaScriptEnabled(true);

        webManual.setWebChromeClient(new WebChromeClient());

        webManual.loadUrl("file:///android_asset/manual.html");


    }






}
