package in.graphisigner.www.paypark;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.content.Context;

public class DBHelper extends SQLiteOpenHelper{
    private final static String DB_NAME = "PayParkDB_Img";
    private final static String TB_NAME_USER = "UserInfo";


    public DBHelper(Context context) {
        super(context, DB_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try
        {

            String CREATE_TABLE = "CREATE TABLE " + TB_NAME_USER + " ( Id INTEGER, "
                    + "Name TEXT, Phone TEXT, City TEXT,"
                    + "Email TEXT PRIMARY KEY , Password TEXT,"
                    + "UserImage BLOB,"
                    + " DOB TEXT);";

            Log.v("On Create table :" , CREATE_TABLE);
            db.execSQL(CREATE_TABLE);

        }
        catch(Exception e)
        {
            Log.e("DBHelper" , e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int olderVersion, int newerVersion) {
        try {
            db.execSQL(" DROP TABLE IF EXISTS " + TB_NAME_USER);
            onCreate(db);
        }
        catch(Exception e)
        {
            Log.e("DBHelper" , e.getMessage());
        }
    }

}
