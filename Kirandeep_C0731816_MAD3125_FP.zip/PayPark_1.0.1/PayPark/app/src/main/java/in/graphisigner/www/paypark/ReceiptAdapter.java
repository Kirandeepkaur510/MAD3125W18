package in.graphisigner.www.paypark;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
/**
 * Created by nkdus on 4/17/2018.
 */

public class ReceiptAdapter extends BaseAdapter {

    Context context;
    String[] paymentCar;
    String[] paymentDate;
    LayoutInflater inflater;

    ReceiptAdapter(Context context,String[] paymentCar, String[] paymentDate){
        this.context = context;
        this.paymentCar = paymentCar;
        this.paymentDate = paymentDate;
        inflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return paymentDate.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = inflater.inflate(R.layout.receipt_spinner,null);

        TextView paymentCarTXT = (TextView) view.findViewById(R.id.paymentCar) ;
        TextView paymentDateTXT = (TextView) view.findViewById(R.id.paymentDate);

        paymentCarTXT.setText(paymentCar[position]);
        paymentDateTXT.setText(paymentDate[position]);
        return view;

    }
}
