package in.graphisigner.www.paypark;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddCar extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Spinner spinCompany;
    String company;
    Button AddVehicle;
    EditText VehNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_car);

        spinCompany = (Spinner) findViewById(R.id.spinCompany);
        CarAdapter carAdapter = new CarAdapter(getApplicationContext(),
                GlobalVariable.carLogo, GlobalVariable.carBrand);
        spinCompany.setAdapter(carAdapter);
        spinCompany.setOnItemSelectedListener(this);

        VehNumber = (EditText) findViewById(R.id.CarPlateNumber);

        AddVehicle = (Button) findViewById(R.id.AddVehicle);
        AddVehicle.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == AddVehicle.getId())
        {
            String vehNo = VehNumber.getText().toString();
            if(vehNo.isEmpty())
            {
                Toast.makeText(this, "Vehicle Registration Number Missing!" , Toast.LENGTH_LONG).show();

            }
            else
            {
                GlobalVariable.carAdded.add(vehNo);
                Toast.makeText(this, "Vehicle Added Successfully!" , Toast.LENGTH_LONG).show();

            }
        }


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if (adapterView.getId() == spinCompany.getId()) {
            company = GlobalVariable.carBrand[position];
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
