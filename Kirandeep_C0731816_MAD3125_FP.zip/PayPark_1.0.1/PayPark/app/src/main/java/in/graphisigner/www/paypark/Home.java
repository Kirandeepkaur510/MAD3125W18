package in.graphisigner.www.paypark;

import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.microedition.khronos.opengles.GL;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    ImageView parkLoc, parkPayment, parkVehicles, parkReport, parkSupport, parkManual, parkLogOut, parkProfile, Menu_UserImage;
    TextView parkLocTxt, parkPaymentTxt, parkVehiclesTxt, parkReportTxt, parkSupportTxt, parkManualTxt, parkLogOutTxt, parkProfileTxt;
    TextView timerHrs, timerMins, timerSecs, Menu_UserName, Menu_UserEmail;


    private Handler handler;
    private Runnable runnable;

    int seconds = 0;
    int minutes = 0;
    int Hrs = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        parkLoc = (ImageView) findViewById(R.id.parkLocationIco);
        parkPayment =  (ImageView) findViewById(R.id.parkPaymentIco);
        parkVehicles = (ImageView) findViewById(R.id.addVehiclesIco);
        parkReport = (ImageView) findViewById(R.id.ParkingReportIco);
        parkSupport = (ImageView) findViewById(R.id.supportContactIco);
        parkManual = (ImageView) findViewById(R.id.parkingManualIco);
        parkLogOut = (ImageView) findViewById(R.id.logOutIco);
        parkProfile = (ImageView) findViewById(R.id.UserProfileIco);





        parkLoc.setOnClickListener(this);
        parkPayment.setOnClickListener(this);
        parkVehicles.setOnClickListener(this);
        parkReport.setOnClickListener(this);
        parkSupport.setOnClickListener(this);
        parkManual.setOnClickListener(this);
        parkLogOut.setOnClickListener(this);
        parkProfile.setOnClickListener(this);

        parkLocTxt = (TextView) findViewById(R.id.parkLocationText);
                parkPaymentTxt = (TextView) findViewById(R.id.parkPaymentText);
                parkVehiclesTxt = (TextView) findViewById(R.id.addVehiclesText);
                parkReportTxt = (TextView) findViewById(R.id.parkingReportText);
                parkSupportTxt = (TextView) findViewById(R.id.supportContactText);
                parkManualTxt = (TextView) findViewById(R.id.parkingManualText);
                parkLogOutTxt = (TextView) findViewById(R.id.logOutText);
                parkProfileTxt = (TextView) findViewById(R.id.userProfileTxt);

        parkLocTxt.setOnClickListener(this);
        parkPaymentTxt.setOnClickListener(this);
        parkVehiclesTxt.setOnClickListener(this);
        parkReportTxt.setOnClickListener(this);
        parkSupportTxt.setOnClickListener(this);
        parkManualTxt.setOnClickListener(this);
        parkLogOutTxt.setOnClickListener(this);
        parkProfileTxt.setOnClickListener(this);

        timerHrs = (TextView) findViewById(R.id.timerHrs);
        timerMins = (TextView) findViewById(R.id.timerMins);
        timerSecs = (TextView) findViewById(R.id.timerSec);

        if (GlobalVariable.RunTimer == true && GlobalVariable.LoggedUser == GlobalVariable.RunTimeUser)
        {
            if (GlobalVariable.RunTimerMins != 0 || GlobalVariable.RunTimerSecs != 0)
            {
                seconds = GlobalVariable.RunTimerSecs;
                minutes = GlobalVariable.RunTimerMins;
                Hrs = GlobalVariable.RunTImerHrs;

                timerHrs.setText(String.valueOf(Hrs));
                timerMins.setText(String.valueOf(minutes));
                timerSecs.setText(String.valueOf(seconds));

            }

            else if (GlobalVariable.RunTImerHrs == 1) {
                Hrs = 0;
                minutes = 59;
                seconds = 60;
                timerHrs.setText(String.valueOf(Hrs));
                timerMins.setText(String.valueOf(minutes));
                timerSecs.setText(String.valueOf(seconds));

            }
            else
            {
                Hrs = GlobalVariable.RunTImerHrs - 1;
                minutes = 59;
                seconds = 60;
                timerHrs.setText(String.valueOf(Hrs));
                timerMins.setText(String.valueOf(minutes));
                timerSecs.setText(String.valueOf(seconds));

            }

            countDownStart();
        }
        else
        {
            timerHrs.setText("XX");
            timerMins.setText("XX");
            timerSecs.setText("XX");

        }

        navigationView.removeHeaderView(navigationView.getHeaderView(0));

        View hView =  navigationView.inflateHeaderView(R.layout.nav_header_home);
        Menu_UserImage = (ImageView)hView.findViewById(R.id.Menu_UserImage);
        Menu_UserName = (TextView)hView.findViewById(R.id.Menu_username);
        Menu_UserEmail = (TextView)hView.findViewById(R.id.Menu_UserId);
        Menu_UserImage.setImageResource(GlobalVariable.UserImage[GlobalVariable.UserIndex]);
        Menu_UserName.setText(GlobalVariable.UserFullName[GlobalVariable.UserIndex]);
        Menu_UserEmail.setText(GlobalVariable.UserName[GlobalVariable.UserIndex]);

        Menu_UserEmail.setOnClickListener(this);
        Menu_UserName.setOnClickListener(this);
        Menu_UserImage.setOnClickListener(this);

        /*
        Menu_UserImage = (ImageView) findViewById(R.id.Menu_UserImage);
        Menu_UserName = (TextView) findViewById(R.id.Menu_username);
        Menu_UserEmail = (TextView) findViewById(R.id.Menu_UserId);
       Menu_UserImage.setImageResource(GlobalVariable.UserImage[GlobalVariable.UserIndex]);
       Menu_UserName.setText(GlobalVariable.UserFullName[GlobalVariable.UserIndex]);
        Menu_UserEmail.setText(GlobalVariable.UserName[GlobalVariable.UserIndex]);

        Menu_UserEmail.setOnClickListener(this);
        Menu_UserName.setOnClickListener(this);
        Menu_UserImage.setOnClickListener(this);
    */
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);


        return true;

}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent profileIntent = new Intent(this, UserProfile.class);
            startActivity(profileIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_location) {
            parkingLocation();
        } else if (id == R.id.nav_payment) {
            parkingPayment();
        } else if (id == R.id.nav_vehicles) {
        addVehicles();
        } else if (id == R.id.nav_ParkingReport) {
    parkingReport();
        } else if (id == R.id.nav_SupportContact) {
            supportContact();
        } else if (id == R.id.nav_PayParkManual) {
        payparkManual();
        }
        else if (id == R.id.nav_LogOut) {
        logOut();
        } else if (id == R.id.nav_UserProfile)
        {
            userProfile();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == parkLoc.getId() || view.getId() == parkLocTxt.getId()) {
        parkingLocation();
        } else if (view.getId() == parkPayment.getId() || view.getId() == parkPaymentTxt.getId()) {
        parkingPayment();
        } else if (view.getId() == parkVehicles.getId() || view.getId() == parkVehiclesTxt.getId()) {
        addVehicles();
        } else if (view.getId() == parkReport.getId() || view.getId() == parkReportTxt.getId()) {
        parkingReport();
        } else if (view.getId() == parkSupport.getId() || view.getId() == parkSupportTxt.getId()) {
            supportContact();
        } else if (view.getId() == parkManual.getId() || view.getId() == parkManualTxt.getId()) {
            payparkManual();
        }
        else if (view.getId() == parkLogOut.getId() || view.getId() == parkLogOutTxt.getId()) {

           logOut();

        }
        else if (view.getId() == parkProfileTxt.getId() || view.getId() == parkProfile.getId()||view.getId() == Menu_UserEmail.getId()||view.getId() == Menu_UserName.getId()||view.getId() == Menu_UserImage.getId())
        {
            userProfile();
        }
    }

    public void parkingLocation(){
        Intent mapIntent = new Intent(this, ParkingLocation.class);
        startActivity(mapIntent);
    }
    public void parkingPayment(){
        Toast.makeText(this, "Parking Payment" , Toast.LENGTH_LONG).show();
        Intent paymentIntent = new Intent(this, Payment.class);
        startActivity(paymentIntent);
    }
    public void addVehicles(){
        Toast.makeText(this, "Add Vehicles" , Toast.LENGTH_LONG).show();
        Intent addVehicleIntent = new Intent(this, AddCar.class);
        startActivity(addVehicleIntent);
    }
    public void parkingReport(){
        Toast.makeText(this, "Parking Report" , Toast.LENGTH_LONG).show();
        Intent reportIntent = new Intent(this, ParkingReport.class);
        startActivity(reportIntent);
    }
    public void supportContact(){
        Toast.makeText(this, "Support Contact" , Toast.LENGTH_LONG).show();
        Intent contactIntent = new Intent(this, SupportContact.class);
        startActivity(contactIntent);
    }
    public void payparkManual(){
        Toast.makeText(this, "Parking Manual" , Toast.LENGTH_LONG).show();
        Intent manualIntent = new Intent(this, ManualActivity.class);
        startActivity(manualIntent);
    }
    public void userProfile(){
        Intent profileIntent = new Intent(this, UserProfile.class);
        startActivity(profileIntent);
    }
    public void logOut(){

        finish();
        Toast.makeText(this, "Log Out" , Toast.LENGTH_LONG).show();
        Intent homeIntent = new Intent(this, LogIn.class);
        startActivity(homeIntent);
    }


    public void countDownStart() {
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(this, 1000);
                try{

                    /*
                    timerHrs.setText(String.valueOf(Hrs));
                timerMins.setText(String.valueOf(minutes));
                timerSecs.setText(String.valueOf(seconds));
                     */

                    seconds = seconds - 1;
                    GlobalVariable.RunTimerSecs = seconds;
                    timerSecs.setText(String.valueOf(seconds));

                    if (seconds == 0)
                    {
                        if (minutes != 0)
                        {
                            minutes = minutes - 1;
                            GlobalVariable.RunTimerMins = minutes;
                            timerMins.setText(String.valueOf(minutes));
                            seconds = 60;
                            GlobalVariable.RunTimerSecs = seconds;
                            timerSecs.setText(String.valueOf(seconds));
                        }
            else
                        {
                            if (Hrs != 0) {
                            Hrs = Hrs - 1;
                            GlobalVariable.RunTImerHrs = Hrs;
                            timerHrs.setText(String.valueOf(Hrs));
                            minutes = 60;
                            GlobalVariable.RunTimerMins = minutes;
                                timerMins.setText(String.valueOf(minutes));

                                seconds = 60;
                            GlobalVariable.RunTimerSecs = seconds;
                                timerSecs.setText(String.valueOf(seconds));
                        }
                else
                            {
                                GlobalVariable.RunTImerHrs = Hrs;
                                GlobalVariable.RunTimerMins = minutes;
                                GlobalVariable.RunTimerSecs = seconds;

                            }
                        }
                    }



                }
                catch (Exception e) {
                    e.printStackTrace();
                }

            }
        };
        handler.postDelayed(runnable, 1 * 1000);
    }

}
