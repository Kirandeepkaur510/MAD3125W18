package in.graphisigner.www.paypark;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.sql.Blob;
import java.util.Calendar;

public class Registration extends AppCompatActivity implements View.OnClickListener{

    private static final int RESULT_LOAD_IMAGE = 1;
    Button btnRegister;
    TextView txtDOB;
    TextView addImage;
    ImageView userImage;

    Uri selectedImage;

    private Bitmap bitmap;

    DBHelper dbHelper;
    SQLiteDatabase PayParkDB_Img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        txtDOB = (TextView) findViewById(R.id.txtDOB);
        txtDOB.setOnClickListener(this);

        userImage = (ImageView) findViewById(R.id.imgUserImage);
        userImage.setOnClickListener(this);

        addImage = (TextView) findViewById(R.id.txtAddImage);
        addImage.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == userImage.getId() || view.getId() == addImage.getId())
        {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);

        }
        else if(view.getId() == btnRegister.getId()) {
            insertUserData();
            displayData();
        }
        else if(view.getId() == txtDOB.getId())
        {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if( requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null)
        {
            selectedImage = data.getData();

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImage);
                // FileInputStream newFIS = new FileInputStream(data.getAbsolutePath());

                userImage.setImageBitmap(bitmap);
            }
            catch (IOException e) {
            e.printStackTrace();
            }


        }
    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month);
            String dd = String.valueOf(dayOfMonth);
            if(month<10)
            {
                mm = "0" + mm ;
            }
            if (dayOfMonth<10)
            {
                dd = "0" + dd;
            }
            txtDOB.setText(mm + "-" + dd + "-" + yy);
        }
    };

    private void insertUserData(){
        EditText txtName = (EditText) findViewById(R.id.txtName);
        EditText txtEmail = (EditText) findViewById(R.id.txtEmail);
        EditText txtPhone = (EditText) findViewById(R.id.txtPhone);
        EditText txtCity = (EditText) findViewById(R.id.txtCity);
        EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
        EditText txtConfirmPassword = (EditText) findViewById(R.id.txtConfirmPassword);
        TextView txtDOB = (TextView) findViewById(R.id.txtDOB);
        ImageView userDP = (ImageView) findViewById(R.id.imgUserImage);

        String name = txtName.getText().toString();
        String phone = txtPhone.getText().toString();
        String email = txtEmail.getText().toString();
        String city = txtCity.getText().toString();
        String password = txtPassword.getText().toString();
        String confirmPassword = txtConfirmPassword.getText().toString();
        String dob = txtDOB.getText().toString();

        if(name.equals("") || phone.equals("") || email.equals("") || city.equals("") || password.equals("") || confirmPassword.equals("") || dob.equals(""))
        {
            Toast.makeText(this, "Data Missing!" , Toast.LENGTH_LONG).show();
        }
        else if (!password.equals(confirmPassword))
        {
            Toast.makeText(this, "Password Doesn't Match!" , Toast.LENGTH_LONG).show();
        }
        else
         {
            String uploadImage = getStringImage(bitmap);


            ContentValues cv = new ContentValues();
            cv.put("Name", name);
            cv.put("Phone", phone);
            cv.put("Email", email);
            cv.put("City", city);
            cv.put("Password", password);
            cv.put("Dob", dob);
            cv.put("Userimage", uploadImage);

            try
            {
                PayParkDB_Img = dbHelper.getWritableDatabase();
                PayParkDB_Img.insert("UserInfo" ,null,cv);
            }
            catch(Exception e)
            {
                Log.e("INSERT USER", e.getMessage());
            }
            PayParkDB_Img.close();
            Toast.makeText(this, "Registration Successful! UserName: " + email , Toast.LENGTH_LONG).show();
            Intent homeIntent = new Intent(this, LogIn.class);
            startActivity(homeIntent);
        }

    }


    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }



    private void displayData()
    {
        try{
            PayParkDB_Img = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Phone","Email","City","Password","DOB"};
            Cursor cursor = PayParkDB_Img.query("UserInfo",columns,null,null,null,null,null);

            while(cursor.moveToNext())
            {
                String name = cursor.getString(cursor.getColumnIndex( "Name"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                String city = cursor.getString(cursor.getColumnIndex("City"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String birthdate = cursor.getString(cursor.getColumnIndex("DOB"));

                String userInfo = name + "\n" + phone + "\n" + email + "\n" + city + "\n" + password + "\n" + birthdate;
                Toast.makeText(this,userInfo, Toast.LENGTH_SHORT).show();
            }
        }
        catch(Exception e)
        {
            Log.e("RegistryActivity:", "Unable To Fetch Records");
        }
    }



}
