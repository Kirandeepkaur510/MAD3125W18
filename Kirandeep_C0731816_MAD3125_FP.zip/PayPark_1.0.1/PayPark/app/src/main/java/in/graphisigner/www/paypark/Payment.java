package in.graphisigner.www.paypark;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Payment extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    EditText VehNo, Hrs, CardHolder, CardNo, CVV, MM, YYYY;
    TextView parkCharge, HST, Total;
    Button Payment, plusHrs, minusHrs;
    Spinner vehNo;
    String vehicle;

    String carsRegs[];

    NumberFormat formatter = new DecimalFormat("#0.00");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        Hrs = (EditText) findViewById(R.id.noHrs);
        CardHolder = (EditText) findViewById(R.id.cardHolderName);
        CardNo = (EditText) findViewById(R.id.cardNo);
        CVV = (EditText) findViewById(R.id.cardCVV);
        MM = (EditText) findViewById(R.id.expiryMM);
        YYYY = (EditText) findViewById(R.id.expiryYYYY);

        parkCharge = (TextView)findViewById(R.id.parkAmt);
        HST = (TextView)findViewById(R.id.hstAmt);
        Total = (TextView)findViewById(R.id.totalAmt);

        String[] carList = new String[GlobalVariable.carAdded.size()];
        carList = GlobalVariable.carAdded.toArray(carList);

        carsRegs = carList;

        Payment = (Button) findViewById(R.id.btnPayment);
        plusHrs = (Button) findViewById(R.id.plusHrs);
        minusHrs = (Button) findViewById(R.id.minusHrs);

        minusHrs.setEnabled(false);
        Hrs.setEnabled(false);

        Payment.setOnClickListener(this);
        plusHrs.setOnClickListener(this);
        minusHrs.setOnClickListener(this);

        vehNo = (Spinner) findViewById(R.id.vehicleSpin);
        vehAdapter vehAdapter = new vehAdapter(getApplicationContext(),carList);
        vehNo.setAdapter(vehAdapter);
        vehNo.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {

        if(view.getId() == Payment.getId() )
        {
            makepayment();
        } else if (view.getId() == plusHrs.getId())
        {

            increaseTimeHrs();

        } else if (view.getId() == minusHrs.getId())
        {
            decreaseTimeHrs();
        }

    }

    public void makepayment(){
        String hours = Hrs.getText().toString();
        String cardName = CardHolder.getText().toString();
        String cardNum = CardNo.getText().toString();
        String cardCVV = CVV.getText().toString();
        String cardMM = MM.getText().toString();
        String cardYYYY = YYYY.getText().toString();

        if (hours.isEmpty()||cardName.isEmpty()||cardNum.isEmpty()||cardCVV.isEmpty() ||
                cardMM.isEmpty()||cardYYYY.isEmpty())
        {
            Toast.makeText(this, "Data Missing!" , Toast.LENGTH_LONG).show();
        }
        else
        {
            Date today = new Date();
            SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
            String datetoday = format.format(today);

            GlobalVariable.parkPayments.add(vehicle);
            GlobalVariable.PaymentDate.add(datetoday);
            GlobalVariable.PayHrs.add(hours);
            GlobalVariable.PayAmt.add(String.valueOf(Total.getText().toString()));

            GlobalVariable.RunTImerHrs = Integer.parseInt(hours);
            GlobalVariable.RunTimer = true;
            GlobalVariable.RunTimeUser = GlobalVariable.LoggedUser;

            Toast.makeText(this, Total.getText().toString() +"Payment Successful for Vehicle No:" + vehicle , Toast.LENGTH_LONG).show();
            Intent homeIntent = new Intent(this, Home.class);
            startActivity(homeIntent);
        }
    }

    public void increaseTimeHrs(){
        int hrsValue = 0;
        String hrsStr;
        int parkCharges = 0;
        double hst = 0, total = 0;
        if (Hrs.getText().toString().equals("Hrs"))
        {
            minusHrs.setEnabled(true);
            hrsValue = 1;
            Hrs.setText( String.valueOf (hrsValue) );

        }
        else {
            hrsStr = Hrs.getText().toString();
            hrsValue = Integer.valueOf(hrsStr);
            hrsValue = hrsValue + 1;
            Hrs.setText( String.valueOf (hrsValue) );
        }

        parkCharges = hrsValue * 5;
        hst = (double) parkCharges * 0.13;
        total = parkCharges + hst;


        parkCharge.setText("$" + String.valueOf(parkCharges) );
        HST.setText("$" + String.valueOf(formatter.format(hst)) );
        Total.setText("$" + String.valueOf(formatter.format(total)) );
    }

    public void decreaseTimeHrs(){
        int hrsValue = 0;
        String hrsStr;

        int parkCharges = 0;
        double hst = 0, total = 0;

        if (Hrs.getText().toString().equals("1"))
        {

            Hrs.setText( "Hrs" );
            minusHrs.setEnabled(false);

            parkCharge.setText("0$");
            HST.setText("0$");
            Total.setText("0$");

        }
        else {
            hrsStr = Hrs.getText().toString();
            hrsValue = Integer.valueOf(hrsStr);
            hrsValue =  hrsValue - 1;
            Hrs.setText( String.valueOf(hrsValue) );

            parkCharges = hrsValue * 5;
            hst = (double) parkCharges * 0.13;
            total = parkCharges + hst;

            parkCharge.setText("$" + String.valueOf(parkCharges) );
            HST.setText("$" + String.valueOf(formatter.format(hst)) );
            Total.setText("$" + String.valueOf(formatter.format(total)) );

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if (adapterView.getId() == vehNo.getId()) {
            vehicle = carsRegs[position];
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
