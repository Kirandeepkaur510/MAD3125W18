package in.graphisigner.www.paypark;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class ParkingReport extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {


    Button back;

    TextView ParkingVehNo;
    TextView ParkingAmt;
    TextView ParkHrs;
    TextView ParkDate;

    Spinner Recipts;
    String ReciptsCar;
    String company;

    String ReceiptsArray[];
    String ReceiptsDate[];
    String ReceiptsPayment[];
    String ReceiptsHrs[];



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_parking_report);

        String ReciptsA[] = new String[GlobalVariable.parkPayments.size()];
        String ReciptsD[] = new String[GlobalVariable.PaymentDate.size()];
        String ReciptsP[] = new String[GlobalVariable.PayAmt.size()];
        String ReciptsH[] = new String[GlobalVariable.PayHrs.size()];

        ReciptsA = GlobalVariable.parkPayments.toArray(ReciptsA);
        ReciptsD = GlobalVariable.PaymentDate.toArray(ReciptsD);
        ReciptsP = GlobalVariable.PayAmt.toArray(ReciptsP);
        ReciptsH = GlobalVariable.PayHrs.toArray(ReciptsH);

        ReceiptsArray = ReciptsA;
        ReceiptsDate = ReciptsD;
        ReceiptsPayment = ReciptsP;
        ReceiptsHrs = ReciptsH;

        back = (Button) findViewById(R.id.btnBackReceipt);
        back.setOnClickListener(this);

        ParkingVehNo = (TextView) findViewById(R.id.GlobalVehNo);
        ParkingAmt = (TextView) findViewById(R.id.GlobalPaidAmt);
        ParkHrs = (TextView) findViewById(R.id.GlobalPaidHrs);
        ParkDate = (TextView) findViewById(R.id.GlobalPaymentDate);


        Recipts = (Spinner) findViewById(R.id.ReceiptSpinner);

        ReceiptAdapter radapter = new ReceiptAdapter(getApplicationContext(),ReceiptsArray , ReceiptsDate);
        Recipts.setAdapter(radapter);
        Recipts.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==back.getId())
        {

            Intent homeIntent = new Intent(this, Home.class);
            startActivity(homeIntent);

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if (adapterView.getId() == Recipts.getId()) {
            company = ReceiptsArray[position];

            ParkingVehNo.setText(ReceiptsArray[position]);
            ParkingAmt.setText(ReceiptsPayment[position]);
            ParkHrs.setText(ReceiptsHrs[position]);
            ParkDate.setText(ReceiptsDate[position]);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

}
