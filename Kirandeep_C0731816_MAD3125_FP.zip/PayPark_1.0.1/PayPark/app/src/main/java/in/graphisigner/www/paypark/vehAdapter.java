package in.graphisigner.www.paypark;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
/**
 * Created by nkdus on 4/17/2018.
 */

public class vehAdapter extends BaseAdapter{

    Context context;
    String[] vehicleNumbers;
    LayoutInflater inflater;

    vehAdapter(Context context, String[] vehicleNumbers){
        this.context = context;
        this.vehicleNumbers = vehicleNumbers;
        inflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return vehicleNumbers.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = inflater.inflate(
                R.layout.vehiclenumber_spinner,
                null);

        TextView vehicleNumber = (TextView) view.findViewById(
                R.id.txtVehicleSpin);

        vehicleNumber.setText(vehicleNumbers[position]);

        return view;

    }
}
